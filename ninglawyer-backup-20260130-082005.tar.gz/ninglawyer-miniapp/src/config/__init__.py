"""
config 包初始化
"""
